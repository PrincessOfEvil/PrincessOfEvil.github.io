package data.utils;

import java.awt.*;

public class FM_Colors {

    public static final Color FM_RED_EMP_FRINGE = new Color(255, 38, 38, 255);
    public static final Color FM_RED_EMP_CORE = new Color(207, 225, 255, 255);
    public static final Color FM_RED_EXPLOSION = new Color(255, 116, 116, 223);

    public static final Color FM_BLUE_FLARE_CORE = new Color(166, 218, 252, 237);
    public static final Color FM_BLUE_FLARE_FRINGE = new Color(64, 131, 243, 235);

}
