package data.campaign.intel.bar.events;

import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEventWithPerson;

public class FM_ContactWithAya extends BaseBarEventWithPerson {
}
