package data.campaign.intel.bar.events;

import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEventCreator;

public class FM_ContactWithAyaCreator extends BaseBarEventCreator {
}
