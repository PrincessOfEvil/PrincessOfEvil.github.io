package data.campaign.intel.bar.events;

import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;

public class FM_ContactWithAyaIntel extends BaseIntelPlugin {
}
