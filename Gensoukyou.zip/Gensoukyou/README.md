# Some important notes for translator.

This mod is in early stage now. 
Its `stability`, `balance` and `Gameplay` (in Chinese 游戏性) may **not good**.
And the `text` may **change a lot** in different versions.

Please thinking **CAREFULLY** before you decided to translate.

**Please check ...\data\strings\strings.json.**

()
